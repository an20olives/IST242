package Model;

public class Model
{


    public Model()
    {
        loadData();
    }

    public void loadData()
    {

    }

}
