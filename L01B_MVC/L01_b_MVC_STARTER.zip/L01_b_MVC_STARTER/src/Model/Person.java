package Model;

public class Person
{

   //bring the contents of your Person class from the first assignment
}
