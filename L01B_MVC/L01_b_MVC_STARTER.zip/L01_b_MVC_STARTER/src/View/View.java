package View;

public class View
{

    public View()
    {

    }

}
