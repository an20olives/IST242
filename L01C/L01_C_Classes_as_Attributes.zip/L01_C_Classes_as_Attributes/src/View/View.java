package View;

public class View {

    public View() {

    }
    
    //Used to print our data to the console
    public void basicDisplay(String s) {// view likes strings, view doesnt know about data/model
        System.out.println(s);
    }

}
